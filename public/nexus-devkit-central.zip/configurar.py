#!/usr/bin/env python3
"""Send the owner's configuration over the local USB serial port, without printing secrets."""
import argparse,json,time,sys
try:
 import serial
 from serial.tools import list_ports
except ImportError:
 raise SystemExit('Instale a dependência: python -m pip install pyserial')
p=argparse.ArgumentParser(description='Configurar Nexus DevKit Central por USB')
p.add_argument('--arquivo',default='provision.json',help='Arquivo baixado ao criar a central')
p.add_argument('--porta',help='Ex.: COM4 ou /dev/ttyUSB0');a=p.parse_args()
try:
 with open(a.arquivo,encoding='utf-8-sig') as f:cfg=json.load(f)
except (OSError,ValueError):raise SystemExit('Não consegui abrir provision.json. Confira o caminho do arquivo.')
if not a.porta:
 print('Portas encontradas:')
 for x in list_ports.comports():print(' ',x.device,'-',x.description)
 a.porta=input('Porta da ESP32 DevKit: ').strip()
ssid=input('Nome da rede Wi-Fi de 2,4 GHz: ').strip();password=input('Senha do Wi-Fi (visível na tela): ')
allowed=['cloudUrl','gatewayId','gatewayToken','serviceToken']
config={k:cfg.get(k,'') for k in allowed};config['wifiSsid']=ssid;config['wifiPassword']=password
if not config['gatewayId'] or not config['gatewayToken']:raise SystemExit('O arquivo não possui credenciais da central.')
line='CONFIG '+json.dumps(config,separators=(',',':'),ensure_ascii=True)+'\n'
try:
 with serial.Serial(a.porta,115200,timeout=.5,write_timeout=5) as dev:
  time.sleep(2);dev.reset_input_buffer();dev.write(line.encode());dev.flush();deadline=time.monotonic()+15
  while time.monotonic()<deadline:
   msg=dev.readline().decode(errors='replace').strip()
   if msg.startswith('CONFIG_OK'):
    print('Configuração salva. A placa vai reiniciar e conectar ao Nexus.');break
   if msg.startswith('CONFIG_ERROR'):raise SystemExit(msg)
  else:raise SystemExit('Sem confirmação. Confira porta/cabo e feche o Monitor Serial antes de tentar novamente.')
except serial.SerialException as err:raise SystemExit('Não foi possível acessar a porta USB. Confira cabo, porta e programas usando o serial.')
print('Abra o Monitor Serial em 115200 baud e procure HTTPS 200 / NEXUS_OK.')
