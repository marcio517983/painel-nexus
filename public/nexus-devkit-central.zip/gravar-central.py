#!/usr/bin/env python3
"""Flash the compiled central image to an explicitly selected ESP32 port."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--porta',default='COM4');a=p.parse_args()
root=Path(__file__).resolve().parent
binary=root/'devkit-central-completo.bin'
try:
 manifest=json.loads((root/'SHA256.json').read_text())
 if hashlib.sha256(binary.read_bytes()).hexdigest()!=manifest[binary.name]:raise ValueError()
except (OSError,ValueError,KeyError):raise SystemExit('Pacote incompleto ou checksum inválido. Extraia novamente o ZIP completo.')
try:import esptool
except ImportError:raise SystemExit('Execute: python -m pip install esptool==4.5.1 pyserial==3.5')
print('DevKit como CENTRAL: GPIO25/23, pulso LOW de 1s. Feche os monitores seriais. Desconecte os contatos de carga durante o teste.')
subprocess.run([sys.executable,'-m','esptool','--chip','esp32','--port',a.porta,'--baud','460800','write_flash','--flash_size','4MB','0x0',str(binary)],check=True)
print('Firmware gravado. Execute: python configurar.py --arquivo provision.json --porta '+a.porta)
