# DevKit como central independente — em validação de bancada

Esta versão substitui a central S3 e o escravo: usa um único ESP32 DevKit clássico (ESP-WROOM-32, flash 4 MB). Não é o firmware antigo de escravo.

- Canal 1: GPIO25, veículos; canal 2: GPIO23, pedestres. Saídas open-drain, LOW por 1000 ms e liberadas em repouso. O GPIO só comanda uma interface de relé compatível com lógica 3,3 V; nunca recebe 5/12 V.
- Timer FreeRTOS desliga o pulso independentemente de espera HTTPS. Inicialização mantém saídas desligadas. Não há reenvio automático de comandos.
- Estado da posição é desconhecido (-1): sensores ainda não implementados nesta variante. Confirmar pulso não confirma abertura.
- HTTPS para a Vercel com validação de certificados, relógio NTP e sem seguir redirecionamentos. Login remoto permanece no servidor; não fornecer senha Master à placa.
- Portal local HTTPS opcional, ativado por certificado via USB. Limite de duas conexões locais. Convites de visitantes ficam exclusivamente no portal online nesta variante; usuários cadastrados e sincronizados podem entrar localmente.
- Até 32 cadastros no protocolo atual, incluindo visitantes. Não promete atender 60 usuários nesta versão.
- OTA desabilitada: binários S3 não podem ser gravados no ESP32 clássico. Atualização por USB.

## Preparar no Windows

Use uma cópia da pasta inteira. Instale ferramentas:

```powershell
python -m pip install esptool==4.5.1 pyserial==3.5 cryptography
python gravar-central.py --porta COM4
python configurar.py --arquivo provision.json --porta COM4
```

O ZIP contém o firmware já compilado, verificado por SHA-256. Para recompilar o código-fonte, instale PlatformIO e execute `python -m platformio run` nesta pasta. A gravação substitui o programa de escravo do DevKit. Não apaga o programa da S3. O provision.json é o já baixado do condomínio na Vercel. Não publique nem envie esse arquivo.

No Master, Equipamentos → + Equipamento → Ligação: Saída da própria central DevKit. Selecione ESP32 DevKit, Acionador, canal 1 (veículos) ou 2 (pedestres). Não exige MAC. Não misture escravos nesta central. Libere ambos para os moradores desejados.

Para HTTPS local, execute `python ativar-portal.py`, informe COM4 e o IP exibido em STATUS. O certificado local requer confiança no dispositivo do usuário. Nunca desative validação TLS da conexão com a nuvem.

## Verificação obrigatória de bancada antes de instalar

Use `python -m serial.tools.miniterm COM4 115200`. Procure HTTPS 200 e os contadores heap/minHeap/maxBlock. Primeiro teste somente a interface de relés com os contatos de carga desconectados. Confira pulso único de aproximadamente 1 segundo em cada canal; reinício e reconexão não devem gerar pulsos.

Teste 30 minutos online, acionamentos alternados e simultâneos, uma sessão HTTPS local, perda e retorno do Wi-Fi, e reinício. Verifique que não há reset, queda progressiva de minHeap/maxBlock ou pulso preso. A revisão de código/compilação não substitui essa medição na placa real.

MKN New Home: contatos COM–NA entre GND e BOT. Ultra: contatos COM–NA entre +12 V e BOT conforme manual Rev.3 página 8; não use NF. A alimentação das fechaduras é independente do sinal lógico do ESP32.

## Resultado da compilação

ESP32 clássico, Arduino 2.0.17 / PlatformIO espressif32 6.10.0: flash 1.076.021 bytes de 3.145.728 bytes da partição de aplicação (34,2%); RAM estática 50.180 de 327.680 bytes (15,3%). Isso não inclui alocações dinâmicas de JSON, Wi-Fi e TLS; a estabilidade deve ser medida na bancada.

A Vercel está exigindo autenticação da plataforma no endereço principal. A placa não consegue passar por esse login. A alteração para deixar somente a produção pública, mantendo previews protegidos, aguarda autorização explícita do proprietário. O login do Nexus e a chave individual do gateway permanecem obrigatórios.
